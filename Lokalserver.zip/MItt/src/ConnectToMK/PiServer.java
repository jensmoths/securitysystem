package ConnectToMK;

import model.*;

import javax.swing.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;

public class PiServer extends Thread implements Serializable {
    private HashMap<SecurityComponent, ClientHandler> map = new HashMap<>();
    ArrayList<SecurityComponent> firesensors = new ArrayList<SecurityComponent>();
    ArrayList<SecurityComponent> magnetSensors = new ArrayList<SecurityComponent>();
    ArrayList<SecurityComponent> proximitySensors = new ArrayList<SecurityComponent>();
    ArrayList<SecurityComponent> doorSensors = new ArrayList<SecurityComponent>();
    GlobalServer globalServer;

    PiServer() throws IOException {
        new StartServer(Integer.parseInt(JOptionPane.showInputDialog(null, "Välj port"))).start();
       // globalServer = new GlobalServer();
        //new Thread(globalServer).start();


    }


    class StartServer extends Thread {

        private int port;
        SecurityComponent sensor;

        StartServer(int port) {
            this.port = port;

        }

        @Override
        public void run() {
            try {
                Socket socket;
                ServerSocket ss = new ServerSocket(port);

                while (true) {
                    socket = ss.accept();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    String who = bufferedReader.readLine();
                    String[] split = who.split("\\|");
                    String id = split[0], location = split[1], type = split[2];

                    switch (type) {
                        case "firealarm":
                            sensor = new FireAlarm(id, location);
                            firesensors.add(sensor);

                            break;
                        case "magnet":
                            sensor = new MagneticSensor(id, location);
                            magnetSensors.add(sensor);
                            break;

                        case "door":
                            sensor = new DoorLock(id, location);
                            doorSensors.add(sensor);
                            ;
                            break;
                        case "proximity":
                            sensor = new ProximitySensor(id, location);
                            proximitySensors.add(sensor);
                    }

                    System.out.println("IP :" + socket.getInetAddress() + " Sensortype: " + sensor.getClass().getSimpleName() + " Location: " + sensor.getLocation() + " SensorID: " + sensor.getId());

                    if (!map.containsKey(sensor)) {
                        ClientHandler ch = new ClientHandler(socket, sensor);
                        map.putIfAbsent(sensor, ch);
                    } else {
                        map.get(sensor).interrupt();
                        ClientHandler ch = new ClientHandler(socket, sensor);
                        map.replace(sensor, ch);
                    }
                    System.out.println(map.size());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class ClientHandler extends Thread {
        private BufferedReader bufferedReader;
        private BufferedWriter bufferedWriter;
        private Socket socket;
        private SecurityComponent sensor;

        ClientHandler(Socket socket, SecurityComponent securityComponent) throws IOException {
            this.socket = socket;
            this.sensor = securityComponent;

            //socket.setSoTimeout(10000);

            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            start();
        }

        @Override
        public void run() {
            while (!interrupted()) {
                try {
                    String stringMessage = bufferedReader.readLine();
                    String[] split = stringMessage.split("\\|");
                    String state = split[0]; //, location = split[1], type = split[2];

                    boolean booleanState = state.equals("on");

                    Message message = sensor.createMessage(sensor, booleanState);
                    globalServer.sendMessage(message);

                    System.out.println(message.getSecurityComponent().isOpen());


                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }

        public void sendMessage(Message msg) throws IOException {
            bufferedWriter.write(msg.getInfo());
            bufferedWriter.flush();
            System.out.println(msg.getInfo());
        }
    }

    class GlobalServer implements Runnable {
        Socket socket;
        ObjectOutputStream oos;
        ObjectInputStream ois;

        public void connect(String ip, int port) throws IOException {
            String clientType = "server";
            socket = new Socket(ip, port);
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());

            oos.writeObject(clientType);
            oos.writeObject("Ammar");

            oos.flush();
        }

        public void sendMessage(Message msg) throws IOException {
            oos.writeObject(msg);
            oos.flush();
            System.out.println("sent message" + socket.toString());
        }

        @Override
        public void run() {
            try {
                connect("83.254.129.68", 3000);
                System.out.println("connected to server");
            } catch (IOException e) {
                e.printStackTrace();
            }

            while (true) {
                try {

                    Message msg = (Message) ois.readObject();

                    System.out.println("Servern skickade: " + msg.getInfo());

                    map.get(msg.getSecurityComponent()).sendMessage(msg);


                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }
    }
}
