package ConnectToMK;

import model.*;

import javax.swing.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;

public class PiServer extends Thread implements Serializable {
    private HashMap<SecurityComponent, ClientHandler> map = new HashMap<>();
    ArrayList<SecurityComponent> firesensors = new ArrayList<SecurityComponent>();
    ArrayList<SecurityComponent> magnetSensors = new ArrayList<SecurityComponent>();
    ArrayList<SecurityComponent> proximitySensors = new ArrayList<SecurityComponent>();
    ArrayList<SecurityComponent> doorSensors = new ArrayList<SecurityComponent>();
    GlobalServer globalServer;

    PiServer() throws IOException {
        new StartServer(Integer.parseInt(JOptionPane.showInputDialog(null, "Välj port"))).start();
        globalServer = new GlobalServer();
        new Thread(globalServer).start();


    }


    class StartServer extends Thread {

        private int port;
        SecurityComponent sensor;

        StartServer(int port) {
            this.port = port;

        }

        @Override
        public void run() {
            try {
                Socket socket;
                ServerSocket ss = new ServerSocket(port);

                while (true) {
                    socket = ss.accept();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    String who = bufferedReader.readLine();
                    String[] split = who.split(" ");


                    switch (split[2]) {
                        case "firealarm":
                            sensor = new FireAlarm(split[0], split[1]);
                            firesensors.add(sensor); //Används inte

                            break;
                        case "magnet":
                            sensor = new MagneticSensor(split[0], split[1]);
                            magnetSensors.add(sensor);
                            break;

                        case "door":
                            sensor = new DoorLock(split[0], split[1]);
                            doorSensors.add(sensor);
                            ;
                            break;
                        case "proximity":
                            sensor = new ProximitySensor(split[0], split[1]);
                            proximitySensors.add(sensor);
                    }

                    System.out.println("IP :" + socket.getInetAddress() + " Sensortype: " + sensor.getClass().getSimpleName() + " Location: " + sensor.getLocation() + " SensorID: " + sensor.getId());


                    ClientHandler ch = new ClientHandler(socket, sensor);
                    map.putIfAbsent(sensor, ch);
                    System.out.println(map.size());


//                    } else {
//                        System.out.println("BLEV BLOCKAD: " + sensor.getId() + " " + " " + sensor.getLocation());
//                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class ClientHandler extends Thread {
        private BufferedReader bufferedReader;
        private BufferedWriter bufferedWriter;
        private Socket socket;
        private SecurityComponent sensor;

        ClientHandler(Socket socket, SecurityComponent securityComponent) throws IOException {
            this.socket = socket;
            this.sensor = securityComponent;

            //socket.setSoTimeout(10000);

            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            start();
        }

        @Override
        public void run() {
            while (true) {
                try {
                    String stringMessage = bufferedReader.readLine();
                    String[] split = stringMessage.split(" ");
                    Message msg = new Message(split[0], sensor);
                    globalServer.sendMessage(msg);


                    if (sensor instanceof MagneticSensor) {
                        for (SecurityComponent s : proximitySensors) {
                            //map.get(s).sendMessage(new Message("Sensor: " + sensor.getId() + "(" + ")" + " Meddelar att: " + "Det brinner i" + " " + sensor.getLocation()));
                            // model.Message msg = new model.Message("Det brinner" , sensor);
                        }
                    } else if (sensor instanceof DoorLock) {

                    }
                } catch (SocketTimeoutException e) {
                    e.printStackTrace();
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            map.remove(sensor);
        }

        public void sendMessage(Message msg) throws IOException {
            bufferedWriter.write(msg.getInfo());
            bufferedWriter.flush();
            System.out.println(msg.getInfo());
        }
    }

    class GlobalServer implements Runnable {
        Socket socket;
        ObjectOutputStream oos;
        ObjectInputStream ois;

        public void connect(String ip, int port) throws IOException {
            String clientType = "server";
            socket = new Socket(ip, port);
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());

            oos.writeObject(clientType);
            oos.writeObject("Ammar");

            oos.flush();
        }

        public void sendMessage(Message msg) throws IOException {
            oos.writeObject(msg);
            oos.flush();
            System.out.println("sent message" + socket.toString());
        }

        @Override
        public void run() {
            try {
                connect("109.228.172.110", 8080);
                System.out.println("connected to server");
            } catch (IOException e) {
                e.printStackTrace();
            }

            while (true) {
                try {

                    Message msg = (Message) ois.readObject();

                    System.out.println("Servern skickade: " + msg.getInfo());

                    map.get(msg.getSecurityComponent()).sendMessage(msg);


                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                    break;
                }
            }
        }
    }
}
