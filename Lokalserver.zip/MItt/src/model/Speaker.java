package model;

public class Speaker extends SecurityComponent {
    private boolean sound;

    public Speaker(String id, String location, boolean sound) {
        super(id, location);
        this.sound = sound;
    }

    public Speaker() {
        super("", "");
        sound = false;
    }

    @Override
    public Message createMessage(SecurityComponent sensor) {
        return null;
    }

    @Override
    public Message createMessage(SecurityComponent sensor, boolean state) {
        return null;
    }

    @Override
    public boolean isOpen() {
        return false;
    }

    public boolean isSounding() {
        return sound;
    }

    public void setSounding(boolean sound) {
        this.sound = sound;
    }
}
