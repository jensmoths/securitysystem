package model;

public class MagneticSensor extends Sensor {
    private boolean open = false;

    public MagneticSensor() {
        super("", "", false);
    }

    public MagneticSensor(String id, String location) {
        super(id, location);
    }

    public MagneticSensor(String id, String location, boolean active) {
        super(id, location, active);
    }

    @Override
    public Message createMessage(SecurityComponent sensor, boolean open) {
        this.open = open;
        return new Message("", this);
    }

    @Override
    public boolean isOpen() {
        return open;
    }

}
