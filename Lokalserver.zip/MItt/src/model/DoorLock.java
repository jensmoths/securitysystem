package model;

public class DoorLock extends SecurityComponent {
    private boolean open;

    public DoorLock(String id, String location, boolean open) {
        super(id, location);
        this.open = open;
    }

    public DoorLock(String id, String location) {
        super(id, location);
        open = false;
    }

    public DoorLock() {
        super("", "");
        open = false;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }
}
