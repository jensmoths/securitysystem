package model;

public class DoorLock extends SecurityComponent {
    private boolean open;

    public DoorLock(String id, String location, boolean open) {
        super(id, location);
        this.open = open;
    }

    public DoorLock(String id, String location) {
        super(id, location);
        open = false;
    }

    public DoorLock() {
        super("", "");
        open = false;
    }

    @Override
    public Message createMessage(SecurityComponent sensor) {
        return new Message(sensor.getId() + "(" + ")" + " Meddelar att: " + "Det brinner i" + " " + sensor.getLocation());
    }

    @Override
    public Message createMessage(SecurityComponent sensor, boolean state) {
        return null;
    }


    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }
}
